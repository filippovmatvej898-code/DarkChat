package com.example.darkchat

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF0B0F14)
private val Panel = Color(0xFF151B23)
private val Purple = Color(0xFF7C5CFC)
private val White = Color(0xFFF2F4F8)
private val Gray = Color(0xFF929BA8)

data class Message(val text: String, val mine: Boolean, val time: String)
data class Chat(
    val id: Int, val name: String, val preview: String, val time: String,
    val color: Color, val messages: List<Message>
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DarkChatApp() }
    }
}

@Composable
fun DarkChatApp() {
    var chats by remember {
        mutableStateOf(listOf(
            Chat(1, "Александр", "Увидимся вечером?", "21:14", Color(0xFF5B8DEF),
                listOf(Message("Привет! Как дела?", false, "21:10"),
                    Message("Всё хорошо, а у тебя?", true, "21:12"),
                    Message("Увидимся вечером?", false, "21:14"))),
            Chat(2, "Мария", "Отправила фотографии", "20:42", Color(0xFFE879A8),
                listOf(Message("Привет! Отправила фотографии", false, "20:42"))),
            Chat(3, "Команда", "Илья: Отличная работа!", "Вчера", Color(0xFF36BFA6),
                listOf(Message("Отличная работа!", false, "18:30")))
        ))
    }
    var selectedId by remember { mutableStateOf<Int?>(null) }
    var search by remember { mutableStateOf("") }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Purple, background = Bg, surface = Panel,
        onBackground = White, onSurface = White
    )) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            val selected = chats.firstOrNull { it.id == selectedId }
            if (selected == null) {
                ChatList(chats.filter { it.name.contains(search, true) }, search,
                    { search = it }, { selectedId = it })
            } else {
                ChatScreen(selected, { selectedId = null }) { text ->
                    val updated = selected.copy(
                        preview = text, time = "Сейчас",
                        messages = selected.messages + Message(text, true, "Сейчас")
                    )
                    chats = chats.map { if (it.id == selected.id) updated else it }
                }
            }
        }
    }
}

@Composable
private fun ChatList(
    chats: List<Chat>, search: String,
    onSearch: (String) -> Unit, onOpen: (Int) -> Unit
) {
    Column(Modifier.fillMaxSize().background(Bg).padding(horizontal = 20.dp)) {
        Spacer(Modifier.height(28.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("DarkChat", color = White, fontSize = 29.sp, fontWeight = FontWeight.Bold)
                Text("Твои разговоры", color = Gray, fontSize = 14.sp)
            }
            Box(Modifier.size(44.dp).background(Panel, CircleShape), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Person, "Профиль", tint = White)
            }
        }
        Spacer(Modifier.height(24.dp))
        Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).padding(14.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Search, "Поиск", tint = Gray)
            Spacer(Modifier.width(10.dp))
            BasicTextField(
                value = search, onValueChange = onSearch, singleLine = true,
                textStyle = androidx.compose.ui.text.TextStyle(color = White, fontSize = 15.sp),
                decorationBox = { inner ->
                    if (search.isEmpty()) Text("Поиск по чатам", color = Gray)
                    inner()
                },
                modifier = Modifier.fillMaxWidth()
            )
        }
        Spacer(Modifier.height(24.dp))
        Text("СООБЩЕНИЯ", color = Gray, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
        Spacer(Modifier.height(12.dp))
        if (chats.isEmpty()) {
            Text("Чаты не найдены", color = Gray, modifier = Modifier.padding(top = 24.dp))
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(chats, key = { it.id }) { chat -> ChatRow(chat) { onOpen(chat.id) } }
            }
        }
    }
}

@Composable
private fun ChatRow(chat: Chat, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(54.dp).background(chat.color, CircleShape), contentAlignment = Alignment.Center) {
            Text(chat.name.take(1).uppercase(), color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(chat.name, color = White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(5.dp))
            Text(chat.preview, color = Gray, fontSize = 13.sp, maxLines = 1)
        }
        Text(chat.time, color = Gray, fontSize = 11.sp)
    }
    HorizontalDivider(color = Color(0xFF222A35))
}

@Composable
private fun ChatScreen(chat: Chat, onBack: () -> Unit, onSend: (String) -> Unit) {
    var draft by remember(chat.id) { mutableStateOf("") }
    Column(Modifier.fillMaxSize().background(Bg)) {
        Row(Modifier.fillMaxWidth().background(Panel).padding(horizontal = 12.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, "Назад", tint = White)
            }
            Box(Modifier.size(38.dp).background(chat.color, CircleShape), contentAlignment = Alignment.Center) {
                Text(chat.name.take(1), color = Color.White, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(10.dp))
            Column {
                Text(chat.name, color = White, fontWeight = FontWeight.SemiBold)
                Text("чат", color = Gray, fontSize = 11.sp)
            }
        }
        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 14.dp),
            contentPadding = PaddingValues(vertical = 18.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(chat.messages) { message ->
                Row(Modifier.fillMaxWidth(),
                    horizontalArrangement = if (message.mine) Arrangement.End else Arrangement.Start) {
                    Column(Modifier.widthIn(max = 290.dp)
                        .background(if (message.mine) Purple else Panel, RoundedCornerShape(18.dp))
                        .padding(horizontal = 14.dp, vertical = 10.dp)) {
                        Text(message.text, color = Color.White, fontSize = 15.sp)
                        Spacer(Modifier.height(4.dp))
                        Text(message.time, color = Color.White.copy(alpha = .65f), fontSize = 10.sp)
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth().background(Panel).padding(10.dp),
            verticalAlignment = Alignment.CenterVertically) {
            BasicTextField(
                value = draft, onValueChange = { draft = it },
                modifier = Modifier.weight(1f).padding(horizontal = 12.dp, vertical = 12.dp),
                textStyle = androidx.compose.ui.text.TextStyle(color = White, fontSize = 15.sp),
                decorationBox = { inner ->
                    if (draft.isEmpty()) Text("Сообщение...", color = Gray)
                    inner()
                }
            )
            IconButton(
                onClick = {
                    val text = draft.trim()
                    if (text.isNotEmpty()) { onSend(text); draft = "" }
                },
                enabled = draft.trim().isNotEmpty(),
                modifier = Modifier.background(Purple, CircleShape).size(44.dp)
            ) {
                Icon(Icons.AutoMirrored.Filled.Send, "Отправить", tint = Color.White)
            }
        }
    }
}
