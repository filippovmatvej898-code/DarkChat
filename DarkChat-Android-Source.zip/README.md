# DarkChat

Минимальный Android-мессенджер на Kotlin и Jetpack Compose.

## Открытие проекта
Откройте папку проекта в Android Studio и дождитесь Gradle Sync.

## Сборка APK
В Android Studio: Build → Build Bundle(s) / APK(s) → Build APK(s).

APK будет находиться в `app/build/outputs/apk/debug/app-debug.apk`.

## Ограничения первой версии
Это демонстрационный интерфейс с локальными тестовыми сообщениями. Он не поддерживает регистрацию,
обмен сообщениями между устройствами, серверную синхронизацию или постоянное хранение переписки.
Для этого потребуется подключить backend, например Firebase Authentication и Cloud Firestore.
